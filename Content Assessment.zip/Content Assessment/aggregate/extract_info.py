import os
import pandas as pd
import re
import matplotlib
import matplotlib.pyplot as plt
import numpy as np

path = r'C:\SAEED\EY-TN-Accelerators\EY-CA-TN\Content Assessment\outputs_Rogers'
path_to_save = r'C:\SAEED\EY-TN-Accelerators\EY-CA-TN\Content Assessment\outputs_Rogers\new'

###############################################################
# Compute stats
###############################################################

df_sas_programs_main = pd.read_csv(os.path.join(path,'df_sas_programs_main.csv'))
# split_data = df_sas_programs_main['id'].str.split('_')
# df_sas_programs_main['Folder'] = split_data.apply(lambda x: '_'.join(x[:-1]))
format_with_commas = lambda x: "{:,}".format(x)

###############################################################
###############################################################
# Applying a filter on the programs
###############################################################
###############################################################
# df_sas_programs_main = df_sas_programs_main.drop_duplicates(subset=['folder', 'main', 'number_of_lines', 'fname'])
# df_sas_programs_main = df_sas_programs_main.drop_duplicates(subset=['fname'])
# df_all_paths_from_Eric = pd.read_csv(os.path.join(os.getcwd(),'all_paths_from_Eric.csv'))['Path_To_File']
df_sas_programs_main['full_name'] = df_sas_programs_main['path'] + '/' + df_sas_programs_main['fname']
# df_sas_programs_main = pd.merge(df_all_paths_from_Eric, 
#                                 df_sas_programs_main, left_on='Path_To_File', 
#                                 right_on='full_name', how='inner')
###############################################################
###############################################################
###############################################################
###############################################################


# Compute stats for all programs
df_all = pd.DataFrame([{'folder': 'All', 
                        'Number of programs': df_sas_programs_main['id'].count(), 
                        'Number of lines of code': df_sas_programs_main['number_of_lines'].sum()}])

# Compute stats for each main folder
df_main = df_sas_programs_main.groupby('main', as_index=False).agg({'id': 'count', 'number_of_lines': 'sum'}).reset_index(drop=True)
df_main = df_main.rename(columns={'main': 'folder', 'id': 'Number of programs', 'number_of_lines': 'Number of lines of code'})
df_main = pd.concat([df_all, df_main], ignore_index=True, sort=False).sort_values(by='Number of lines of code', ascending=False).reset_index(drop=True)
df_main['Number of lines of code'] = df_main['Number of lines of code'].apply(format_with_commas)
df_main['Number of programs'] = df_main['Number of programs'].apply(format_with_commas)
df_main.to_csv(os.path.join(path_to_save,'df_number_of_lines_by_main_folder.csv'))


# Plot number of lines of code
# plt.figure(figsize=(10, 5))
# bin_values = df_sas_programs_main['number_of_lines'].values
# bin_values = [min(a,2001) for a in bin_values]
# plt.hist(bin_values, bins=40, color='skyblue', edgecolor='black')
# plt.xlabel('Number of lines of code')
# plt.ylabel('Frequency')
# plt.title('Histogram of programs based on number of lines')
# plt.show()


print('################################################')
print(df_main)

# Compute stats for each sub folder
df_sub = df_sas_programs_main.groupby('folder', as_index=False).agg({'id': 'count', 'number_of_lines': 'sum'}).reset_index(drop=True)
df_sub = df_sub.rename(columns={'id': 'Number of programs', 'number_of_lines': 'Number of lines of code'})
df_sub = pd.concat([df_all, df_sub], ignore_index=True, sort=False).sort_values(by='Number of lines of code', ascending=False).reset_index(drop=True)
df_sub['Number of lines of code'] = df_sub['Number of lines of code'].apply(format_with_commas)
df_sub['Number of programs'] = df_sub['Number of programs'].apply(format_with_commas)
df_sub.to_csv(os.path.join(path_to_save,'df_number_of_lines_by_sub_folder.csv'))
print('################################################')
print(df_sub)




###############################################################
# Compute distinct oracle libraries
###############################################################
df_sas_programs_details = pd.read_csv(os.path.join(path,'df_sas_programs_details.csv'), sep=',')
df_sas_programs_details = pd.merge(df_sas_programs_details, df_sas_programs_main['id'], on='id', how='inner')
oracle_rows = df_sas_programs_details[df_sas_programs_details['type'] == 'libname']
oracle_rows = oracle_rows[oracle_rows['original'].str.contains('oracle', case=False, na=False)]
oracle_rows = oracle_rows.\
                groupby(['original'], as_index=False).\
                    agg({'id': 'count'}).\
                        reset_index(drop=True).\
                            sort_values(by='id', ascending=False)

oracle_rows = oracle_rows.rename(columns={'id': 'Number of times refered'})
oracle_rows.to_csv(os.path.join(path_to_save,'oracle_rows.csv'))


###############################################################
# Compute most used proc statements
###############################################################

df_sas_programs_proc_list = pd.read_csv(os.path.join(path,'df_sas_programs_proc_list.csv'), sep=',')
df_sas_programs_proc_list = pd.merge(df_sas_programs_proc_list, df_sas_programs_main, on='id', how='inner')
df_sas_programs_proc_list['proc'] = df_sas_programs_proc_list['proc'].str.split(r'\\n').str[0]

df_folder_to_lob = pd.read_csv(os.path.join(os.getcwd(),'map_path_to_folder.csv'), sep=',', encoding='latin-1')
df_sas_programs_proc_list = pd.merge(df_sas_programs_proc_list, df_folder_to_lob, on='folder', how='left')

df_procs = df_sas_programs_proc_list.groupby(['LoB','proc'], as_index=False).\
            agg({'id': 'count'}).\
                reset_index(drop=True).\
                    sort_values(by='id', ascending=False)
df_procs = df_procs.rename(columns={'id': 'Count'})
df_procs = pd.pivot_table(df_procs, values='Count', index='proc', columns='LoB', aggfunc='sum')
df_procs['Sum'] = df_procs.sum(axis=1)
df_procs = df_procs.sort_values(by='Sum', ascending=False)
df_procs.to_csv(os.path.join(path_to_save,'df_procs.csv'), encoding='latin-1')

# matplotlib.rcParams['font.size'] = 14
# plt.pie(df_procs['Sum'], labels=df_procs.index, autopct='%1.1f%%', startangle=90)
# plt.title('Proc statement frequency of use')
# plt.show()

df_modeling_procs = pd.read_csv(os.path.join(os.getcwd(),'modeling_procs.csv'), sep=',')
proc_vals = df_modeling_procs['proc'].values
proc_vals = [a.split(' ')[-1].lower().strip() for a in proc_vals]
df_modeling_procs = df_procs[df_procs.index.str.lower().isin(proc_vals)]
df_modeling_procs = df_modeling_procs.fillna(0)
df_modeling_procs = df_modeling_procs[df_modeling_procs.index != 'Sum']
df_modeling_procs = df_modeling_procs.transpose()
df_modeling_procs.to_csv(os.path.join(path_to_save,'df_modeling_procs.csv'), encoding='latin-1')

df_etl_procs = pd.read_csv(os.path.join(os.getcwd(),'etl_procs.csv'), sep=',')
proc_vals = df_etl_procs['proc'].values
proc_vals = [a.split(' ')[-1].lower().strip() for a in proc_vals]
df_etl_procs = df_procs[df_procs.index.str.lower().isin(proc_vals)]
df_etl_procs = df_etl_procs.fillna(0)
df_etl_procs = df_etl_procs[df_etl_procs.index != 'Sum']
df_etl_procs = df_etl_procs.transpose()
df_etl_procs.to_csv(os.path.join(path_to_save,'df_etl_procs.csv'), encoding='latin-1')

###############################################################
###############################################################
###############################################################
###############################################################
# Compute program matrix
###############################################################
###############################################################
###############################################################
###############################################################

# Compute input/output tables
###############################################################
df_sas_programs_table_relationships = pd.read_csv(os.path.join(path,'df_sas_programs_table_relationships.csv'), sep=',')

df_sas_programs_main_matrix = pd.merge(df_sas_programs_main, 
                                       df_sas_programs_table_relationships[['id','statement', 'table', 'columns', 'tables_source', 'join_type', 'join_table']], 
                                       on='id', 
                                       how='left')

df_sas_programs_main_matrix = df_sas_programs_main_matrix.fillna('')

df_folder_to_lob = pd.read_csv(os.path.join(os.getcwd(),'map_path_to_folder.csv'), 
                               sep=',', 
                               encoding='latin-1')[['folder','LoB','criticality','global_usecase',
                                                    'number_of_active_users','number_of_inactive_users']]

df_sas_programs_main_matrix = pd.merge(df_sas_programs_main_matrix, df_folder_to_lob, on='folder', how='left')

# df_sas_programs_main_matrix = df_sas_programs_main_matrix.groupby(['id', 'main', 'number_of_lines', 'path', 'fname', 'folder'], as_index=False).\
#     agg({'table': lambda x: len(set([a for a in x if a != ''])), 
#          'tables_source': lambda x: len(set([a for a in x if a != ''])),
#          'join_table':lambda x: len(set([a for a in x if a != '']))}).reset_index(drop=True)


df_sas_programs_main_matrix = df_sas_programs_main_matrix.groupby(['id', 'main', 'number_of_lines', 'path', 'fname', 'folder','criticality', 
                                                                   'global_usecase', 'number_of_active_users','number_of_inactive_users',
                                                                   'LoB','count_stp','count_cond','count_loop','pass_through',
                                                                   'hash','index_create','username','count_x_command'], as_index=False).\
    agg({'table': lambda x: ','.join(x), 
         'tables_source': lambda x: ','.join(x), 
         'columns': lambda x: ','.join([a.lower().strip().split('as')[0].split(')')[0].strip() 
                                        for b in x for a in b.split(',') if a.strip() not in ['*','',None]]), 
         'join_table':lambda x: ','.join(x)}).reset_index(drop=True)

df_sas_programs_main_matrix = df_sas_programs_main_matrix.rename(columns={'table': 'output_tables'})
df_sas_programs_main_matrix['input_tables'] = df_sas_programs_main_matrix[['tables_source', 'join_table']].agg(','.join, axis=1)

df_sas_programs_details = pd.read_csv(os.path.join(path,'df_sas_programs_details.csv'), sep=',')
df_sas_programs_details = df_sas_programs_details.loc[df_sas_programs_details['type'].isin(['create_table','select_from_table']),['id','type','key','value_0']]
df_sas_programs_details = df_sas_programs_details.groupby(['id','type'], as_index=False).\
    agg({'value_0': lambda x: ','.join(x)}).reset_index(drop=True)

df_sas_programs_details['value_0'] = df_sas_programs_details['value_0'].astype(str)
df_sas_programs_details['value_0'] = df_sas_programs_details['value_0'].str.split('\\n',expand=True)[0]\
    .str.replace('[','').str.replace(']','').str.replace(';','').str.replace('"','').str.replace("'",'')

df_create_tbl = df_sas_programs_details.loc[df_sas_programs_details['type'] == 'create_table',['id','value_0']]
df_create_tbl = df_create_tbl.rename(columns={'value_0': 'create_table'})
df_slc_tbl = df_sas_programs_details.loc[df_sas_programs_details['type'] == 'select_from_table',['id','value_0']]
df_slc_tbl = df_slc_tbl.rename(columns={'value_0': 'select_from_table'})

df_sas_programs_main_matrix = pd.merge(df_sas_programs_main_matrix, df_create_tbl, on='id', how='left')
df_sas_programs_main_matrix = pd.merge(df_sas_programs_main_matrix, df_slc_tbl, on='id', how='left')

df_sas_programs_main_matrix['select_from_table'] = df_sas_programs_main_matrix['select_from_table'].astype(str).replace("nan",'')
df_sas_programs_main_matrix['create_table'] = df_sas_programs_main_matrix['create_table'].astype(str).replace("nan",'')

# df_sas_programs_main_matrix['input_tables'] = df_sas_programs_main_matrix[['input_tables', 'select_from_table']].agg(','.join, axis=1)
# df_sas_programs_main_matrix['output_tables'] = df_sas_programs_main_matrix[['output_tables', 'create_table']].agg(','.join, axis=1)

for indx, row in df_sas_programs_main_matrix.iterrows():

    lst_slc   = [a for a in row['select_from_table'].split(',') if a!= '' and a.lower() not in ['_null_','=','from','connection']]
    lst_input = [a for a in row['input_tables'].split(',') if a!= '' and a.lower() not in ['_null_','=','from','connection']]
    lst_input.extend([a for a in lst_slc if a not in lst_input])
    df_sas_programs_main_matrix.loc[indx,'input_tables'] = ','.join([a.split(r"\\")[0] for a in lst_input])

    lst_crt   = [a for a in row['create_table'].split(',') if a!= '' and a.lower() not in ['_null_','=','from','connection']]
    lst_output = [a for a in row['output_tables'].split(',') if a!= '' and a.lower() not in ['_null_','=','from','connection']]
    lst_output.extend([a for a in lst_crt if a not in lst_input])
    df_sas_programs_main_matrix.loc[indx,'output_tables'] = ','.join([a.split(r'\\')[0] for a in lst_output])



lst_out = df_sas_programs_main_matrix['output_tables'].values
lst_in  = df_sas_programs_main_matrix['input_tables'].values
redundant_inputs = [[a for a in lst_in[x].split(',') if a not in lst_out[x].split(',')] for x in range(len(lst_in))]
redundant_inputs = [len(a) - len(set(a)) for a in redundant_inputs]

df_sas_programs_main_matrix['redundant_inputs'] = redundant_inputs
df_sas_programs_main_matrix['redundant_outputs'] = df_sas_programs_main_matrix['output_tables'].str.split(',').apply(lambda x: len([a for a in x]) - len(set([a for a in x])))
df_sas_programs_main_matrix['count_output_tables']     = df_sas_programs_main_matrix['output_tables'].str.split(',').apply(lambda x: len(set([a for a in x])))
df_sas_programs_main_matrix['count_input_tables']      = df_sas_programs_main_matrix['input_tables'].str.split(',').apply(lambda x: len(set([a for a in x])))

df_sas_programs_main_matrix['all_tables'] = df_sas_programs_main_matrix['count_output_tables'] + df_sas_programs_main_matrix['count_input_tables']
df_sas_programs_main_matrix = df_sas_programs_main_matrix.sort_values(by='all_tables', ascending=False)

# Compute dependencies
###############################################################

df_dep = pd.read_csv(os.path.join(path,'df_dep.csv'), sep=',')
df_dep = df_dep.groupby(['id'], as_index=False).agg({'reference': lambda x: ','.join(set(x))}).reset_index(drop=True)
df_sas_programs_main_matrix = pd.merge(df_sas_programs_main_matrix, df_dep, on='id', how='left')

# Compute db engines
###############################################################
df_sas_programs_details = pd.read_csv(os.path.join(path,'df_sas_programs_details.csv'), sep=',')
df_sas_programs_details = df_sas_programs_details.loc[df_sas_programs_details['type'] == 'libname',['id','type','key']]
df_sas_programs_details = df_sas_programs_details.fillna('')
df_sas_programs_details.loc[df_sas_programs_details['key'] == 'access','key'] = 'base'
df_sas_programs_details = pd.pivot_table(df_sas_programs_details, values='type', index='id', columns='key', aggfunc='count')
df_sas_programs_details = df_sas_programs_details.fillna(0)
df_sas_programs_details['id'] = df_sas_programs_details.index
df_sas_programs_details = df_sas_programs_details.reset_index(drop=True)
df_sas_programs_main_matrix = pd.merge(df_sas_programs_main_matrix, df_sas_programs_details, on='id', how='left')

# Compute macros
###############################################################
df_sas_programs_details = pd.read_csv(os.path.join(path,'df_sas_programs_details.csv'), sep=',')
df_sas_programs_details = df_sas_programs_details.loc[df_sas_programs_details['type'] == 'macro',['id','type']]
df_sas_programs_details = df_sas_programs_details.groupby(['id'], as_index=False).agg({'type': 'count'}).reset_index(drop=True)
df_sas_programs_details = df_sas_programs_details.rename(columns={'type': 'macro'})
df_sas_programs_main_matrix = pd.merge(df_sas_programs_main_matrix, df_sas_programs_details, on='id', how='left')

# Add modeling and ETL procs
###############################################################
df_sas_programs_proc_list = pd.read_csv(os.path.join(path,'df_sas_programs_proc_list.csv'), sep=',')
df_sas_programs_proc_list['proc'] = df_sas_programs_proc_list['proc'].str.split(r'\\n').str[0]

df_proc_cats = pd.read_csv(os.path.join(os.getcwd(),'proc_cats.csv'), sep=',')
df_proc_cats['proc'] = df_proc_cats['proc'].str.split(' ').str[-1].str.lower()

etl_proc_vals = df_proc_cats.loc[df_proc_cats['label'] == 'etl','proc'].values
stat_proc_vals = df_proc_cats.loc[df_proc_cats['label'] == 'stat','proc'].values
bi_proc_vals = df_proc_cats.loc[df_proc_cats['label'] == 'bi','proc'].values

df_sas_programs_proc_list.loc[df_sas_programs_proc_list['proc'].isin(etl_proc_vals), 'etl_proc'] = 1
df_sas_programs_proc_list.loc[df_sas_programs_proc_list['proc'].isin(stat_proc_vals), 'stat_proc'] = 1
df_sas_programs_proc_list.loc[df_sas_programs_proc_list['proc'].isin(bi_proc_vals), 'bi_proc'] = 1
df_sas_programs_proc_list = df_sas_programs_proc_list.groupby('id', as_index=False).agg({'etl_proc': 'count',
                                                                                         'stat_proc': 'count',
                                                                                         'bi_proc': 'count'}).reset_index(drop=True)

sum_all = (df_sas_programs_proc_list['etl_proc'] + df_sas_programs_proc_list['stat_proc'] + df_sas_programs_proc_list['bi_proc'])

df_sas_programs_proc_list['etl_percentage'] = df_sas_programs_proc_list['etl_proc']/sum_all
df_sas_programs_proc_list['stat_percentage'] = df_sas_programs_proc_list['stat_proc']/sum_all
df_sas_programs_proc_list['bi_percentage'] = df_sas_programs_proc_list['bi_proc']/sum_all
df_sas_programs_proc_list = df_sas_programs_proc_list.fillna(0)

df_sas_programs_main_matrix = pd.merge(df_sas_programs_main_matrix, df_sas_programs_proc_list, on='id', how='left')

# Compute program complexity
###############################################################
###############################################################
###############################################################
###############################################################

df_sas_programs_main_matrix = df_sas_programs_main_matrix.fillna(0)

# Number of lines
number_of_lines_bins = [-np.inf, 250, 500, 1000,2000,5000,10000,50000,np.inf]
number_of_lines_lbls = ['<250', '250-500', '500-1000', '1000-2000','2000-5000','5000-10000','10000-50000','500000+']
number_of_lines_cats = [1,2,3,4,5,6,7,8]
df_sas_programs_main_matrix['number_of_lines_range'] = pd.cut(df_sas_programs_main_matrix['number_of_lines'], number_of_lines_bins, labels=number_of_lines_lbls)
df_sas_programs_main_matrix['number_of_lines_cats']  = pd.cut(df_sas_programs_main_matrix['number_of_lines'], number_of_lines_bins, labels=number_of_lines_cats)

# count_stp
count_stp_bins = [-np.inf, 2,np.inf]
count_stp_lbls = ['<2', '2+']
count_stp_cats = [1,2]
df_sas_programs_main_matrix['count_stp_range'] = pd.cut(df_sas_programs_main_matrix['count_stp'], count_stp_bins, labels=count_stp_lbls)
df_sas_programs_main_matrix['count_stp_cats']  = pd.cut(df_sas_programs_main_matrix['count_stp'], count_stp_bins, labels=count_stp_cats)

# count_cond
count_cond_bins = [-np.inf, 5,10,30,50,np.inf]
count_cond_lbls = ['<5', '5-10','10-30','30-50','50+']
count_cond_cats = [1,2,3,4,5]
df_sas_programs_main_matrix['count_cond_range'] = pd.cut(df_sas_programs_main_matrix['count_cond'], count_cond_bins, labels=count_cond_lbls)
df_sas_programs_main_matrix['count_cond_cats']  = pd.cut(df_sas_programs_main_matrix['count_cond'], count_cond_bins, labels=count_cond_cats)

# count_loop
count_loop_bins = [-np.inf, 2,5,10,20,50,np.inf]
count_loop_lbls = ['<2', '2-5','5-10','10-20','20-50','50+']
count_loop_cats = [1,2,3,4,5,6]
df_sas_programs_main_matrix['count_loop_range'] = pd.cut(df_sas_programs_main_matrix['count_loop'], count_loop_bins, labels=count_loop_lbls)
df_sas_programs_main_matrix['count_loop_cats']  = pd.cut(df_sas_programs_main_matrix['count_loop'], count_loop_bins, labels=count_loop_cats)

# output_tables
output_tables_bins = [-np.inf, 10,50,400,np.inf]
output_tables_lbls = ['<10', '10-50','50-400','400+']
output_tables_cats = [1,2,3,4]
df_sas_programs_main_matrix['output_tables_range'] = pd.cut(df_sas_programs_main_matrix['count_output_tables'], output_tables_bins, labels=output_tables_lbls)
df_sas_programs_main_matrix['output_tables_cats']  = pd.cut(df_sas_programs_main_matrix['count_output_tables'], output_tables_bins, labels=output_tables_cats)

# input_tables
input_tables_bins = [-np.inf, 10,50,np.inf]
input_tables_lbls = ['<10', '10-50','50+']
input_tables_cats = [1,2,3]
df_sas_programs_main_matrix['input_tables_range'] = pd.cut(df_sas_programs_main_matrix['count_input_tables'], input_tables_bins, labels=input_tables_lbls)
df_sas_programs_main_matrix['input_tables_cats']  = pd.cut(df_sas_programs_main_matrix['count_input_tables'], input_tables_bins, labels=input_tables_cats)

# macro
macro_bins = [-np.inf, 2,5,10,np.inf]
macro_lbls = ['<2', '2-5','5-10','10+']
macro_cats = [1,2,3,4]
df_sas_programs_main_matrix['macro_range'] = pd.cut(df_sas_programs_main_matrix['macro'], macro_bins, labels=macro_lbls)
df_sas_programs_main_matrix['macro_cats']  = pd.cut(df_sas_programs_main_matrix['macro'], macro_bins, labels=macro_cats)

# etl
etl_bins = [-np.inf, 10,50,100,np.inf]
etl_lbls = ['<10', '10-50','50-100','100+']
etl_cats = [1,2,3,4]
df_sas_programs_main_matrix['etl_range'] = pd.cut(df_sas_programs_main_matrix['etl_proc'], etl_bins, labels=etl_lbls)
df_sas_programs_main_matrix['etl_cats']  = pd.cut(df_sas_programs_main_matrix['etl_proc'], etl_bins, labels=etl_cats)

# stat modeling
modeling_bins = [-np.inf, 5,10,50,np.inf]
modeling_lbls = ['<5', '5-10','10-50','50+']
modeling_cats = [1,2,3,4]
df_sas_programs_main_matrix['stat_range'] = pd.cut(df_sas_programs_main_matrix['stat_proc'], modeling_bins, labels=modeling_lbls)
df_sas_programs_main_matrix['stat_cats']  = pd.cut(df_sas_programs_main_matrix['stat_proc'], modeling_bins, labels=modeling_cats)


df_sas_programs_main_matrix['complexity'] = \
0.15 * df_sas_programs_main_matrix['number_of_lines_cats'].astype(float) +\
0.05 * df_sas_programs_main_matrix['count_stp_cats'].astype(float) +\
0.1 * df_sas_programs_main_matrix['count_cond_cats'].astype(float) +\
0.1 * df_sas_programs_main_matrix['count_loop_cats'].astype(float) +\
0.15 * df_sas_programs_main_matrix['output_tables_cats'].astype(float) +\
0.15 * df_sas_programs_main_matrix['input_tables_cats'].astype(float) +\
0.15 * df_sas_programs_main_matrix['etl_cats'].astype(float) +\
0.1 * df_sas_programs_main_matrix['stat_cats'].astype(float) +\
0.05 * df_sas_programs_main_matrix['macro_cats'].astype(float)


# Complexity labeling
complexity_bins = [-np.inf, 1.5,2.5,np.inf]
complexity_lbls = ['Simple', 'Medium','Complex']
df_sas_programs_main_matrix['complexity_cats'] = pd.cut(df_sas_programs_main_matrix['complexity'], complexity_bins, labels=complexity_lbls)

# ETL vs Stat vs BI modeling labels
df_sas_programs_main_matrix['ETL_Stat_Modeling'] = ''
# df_sas_programs_main_matrix.loc[df_sas_programs_main_matrix['etl_percentage'] <= 0.99, 'ETL_Stat_Modeling'] = 'Stat_modeling'
# df_sas_programs_main_matrix.loc[df_sas_programs_main_matrix['stat_percentage'] <= df_sas_programs_main_matrix['bi_percentage'], 'ETL_Stat_Modeling'] = 'BI_modeling'
# df_sas_programs_main_matrix.loc[df_sas_programs_main_matrix['etl_percentage'] > 0.99, 'ETL_Stat_Modeling'] = 'Data preparation'

# df_sas_programs_main_matrix.loc[(df_sas_programs_main_matrix['etl_percentage'] == 0) & 
#                                 (df_sas_programs_main_matrix['stat_percentage'] == 0) &
#                                 (df_sas_programs_main_matrix['bi_percentage'] == 0), 'ETL_Stat_Modeling'] = 'Data preparation'

df_sas_programs_main_matrix.loc[df_sas_programs_main_matrix['stat_proc'] > 0, 'ETL_Stat_Modeling'] = 'Stat_modeling'
df_sas_programs_main_matrix.loc[(df_sas_programs_main_matrix['stat_proc'] == 0) & (df_sas_programs_main_matrix['bi_proc'] > 0), 'ETL_Stat_Modeling'] = 'BI_modeling'
df_sas_programs_main_matrix.loc[df_sas_programs_main_matrix['ETL_Stat_Modeling'] == '', 'ETL_Stat_Modeling'] = 'Data preparation'

# Hardcoded paths
df_sas_programs_hard_coded_paths = pd.read_csv(os.path.join(path,'df_sas_programs_hard_coded_paths.csv'), sep=',')
df_sas_programs_hard_coded_paths = df_sas_programs_hard_coded_paths.groupby(['id'], as_index=False).agg({'hrd_code': 'count'}).reset_index(drop=True)
df_sas_programs_main_matrix = pd.merge(df_sas_programs_main_matrix, df_sas_programs_hard_coded_paths, on='id', how='left')



# Use case analysis
###############################################################
###############################################################
###############################################################
###############################################################
df_sas_programs_main_matrix['full_name'] = df_sas_programs_main_matrix['LoB'] + '/' + df_sas_programs_main_matrix['path'] + '/' + df_sas_programs_main_matrix['fname']
df_use_case = df_sas_programs_main_matrix.groupby(['main','path','LoB','folder'], as_index=False).agg({'number_of_lines': 'sum',
                                                                                       'id': 'count',
                                                                                       'reference': lambda x: ','.join(list(set((','.join([a for a in x if a != 0])).split(',')))),
                                                                                       'etl_proc': 'sum',
                                                                                       'stat_proc': 'sum',
                                                                                       'bi_proc': 'sum',
                                                                                       'etl_percentage': 'mean',
                                                                                       'stat_percentage': 'mean',
                                                                                       'bi_percentage': 'mean',
                                                                                       'hrd_code': 'count',
                                                                                       'complexity': 'mean',
                                                                                       'count_cond':  'sum',
                                                                                       'count_loop': 'sum',
                                                                                       'pass_through': 'sum',
                                                                                       'username': 'sum',
                                                                                       'input_tables': lambda x: ','.join(list(set((','.join([a for a in x if a not in ['',None]])).split(',')))),
                                                                                       'output_tables': lambda x: ','.join(list(set((','.join([a for a in x  if a not in ['',None]])).split(',')))),
                                                                                       'columns': lambda x: ','.join(list(set((','.join([a for a in x])).split(',')))),
                                                                                       'count_input_tables': 'sum',
                                                                                       'count_output_tables': 'sum',
                                                                                       'redundant_inputs': 'sum',
                                                                                       'redundant_outputs': 'sum',
                                                                                       'base': 'sum',
                                                                                       'cvp': 'sum',
                                                                                       'db2': 'sum',
                                                                                       'excel': 'sum',
                                                                                       'odbc': 'sum',
                                                                                       'oracle': 'sum',
                                                                                       'pcfiles': 'sum',
                                                                                       'xml': 'sum',
                                                                                       'macro': 'sum',
                                                                                       'full_name': lambda x: ','.join(x)}).reset_index(drop=True)

df_use_case = df_use_case.rename(columns={'id': 'number_of_programs'})
df_use_case['input_tables'] = df_use_case['input_tables'].str.slice(0,32000)
df_use_case['output_tables']  = df_use_case['output_tables'].str.slice(0,32000)

############################################################################
############################################################################
############################################################################
# Use case definition using LLM
############################################################################
############################################################################
############################################################################

import openai
openai.api_type = "..."
openai.api_key = "..."
openai.api_base = "..."
openai.api_version = '...'

df_use_case['usecase_name'] = ''
for index, row in df_use_case.iterrows():
    msg = [{"role": "system",
            "content": """
        You are a SAS use case name generator based on a list of comma separated directories and SAS program names that are sent to you. 
        Take the list and create one meaningfull name with maximum 5 words that is separated by space and is general enough to cover all
        directories and programs that are entered. In the directories there are some redundant words that need to be ignored. If the names
        are in French, translate them to English
        """}]
    msg.append({'role': 'user', 'content': row['full_name']})
    response = openai.ChatCompletion.create(engine = "gpt4", messages=msg)
    try:
        df_use_case.at[index,'usecase_name'] = response['choices'][0]['message']['content']
    except:
        print('index {0} use case definition was unsuccessful!'.format(str(index)))
    if index % 10 == 0:
        print(index)

############################################################################
############################################################################
############################################################################
# Use case definition using previously defined use cases

df_path_to_usecase = pd.read_csv(os.path.join(path_to_save,'path_to_usecase.csv'), encoding='latin-1')
df_use_case = pd.merge(df_use_case, 
                       df_path_to_usecase, on='path', how='left')
df_sas_programs_main_matrix = pd.merge(df_sas_programs_main_matrix, 
                       df_path_to_usecase, on='path', how='left')

# Save the output
###############################################################
df_sas_programs_main_matrix.to_csv(os.path.join(path_to_save,'df_sas_programs_main_matrix.csv'), encoding='latin-1')

############################################################################
############################################################################
############################################################################

# ETL vs Stat vs BI modeling labels
df_use_case['ETL_Stat_Modeling'] = '' 
df_use_case.loc[df_use_case['etl_percentage'] <= 0.99, 'ETL_Stat_Modeling'] = 'Stat_modeling'
df_use_case.loc[df_use_case['stat_percentage'] <= df_use_case['bi_percentage'], 'ETL_Stat_Modeling'] = 'BI_modeling'
df_use_case.loc[df_use_case['etl_percentage'] > 0.99, 'ETL_Stat_Modeling'] = 'ETL'

df_use_case.loc[(df_use_case['etl_percentage'] == 0) & 
                (df_use_case['stat_percentage'] == 0) &
                (df_use_case['bi_percentage'] == 0), 'ETL_Stat_Modeling'] = 'None'

                                                                                       
# Complexity labeling
df_use_case['complexity_cats'] = pd.cut(df_use_case['complexity'], complexity_bins, labels=complexity_lbls)
df_use_case = df_use_case.drop('full_name',axis=1)
df_use_case.to_csv(os.path.join(path_to_save,'df_use_case.csv'), encoding='latin-1')


# Table interactions with programs
###############################################################
###############################################################
###############################################################
###############################################################
df_in_out_tables = []
exclude_lst = ['where','oracle','select', '(', ')', '*', 'join','test','for']
for indx, row in df_sas_programs_main_matrix.iterrows():
    in_tbls = list(set([a.strip().replace(r'\t','').lower() for a in row['input_tables'].split(',')]))
    out_tbls = list(set([a.strip().replace(r'\t','').lower() for a in row['output_tables'].split(',')]))
    for item in in_tbls:
        if item != '' and '%' not in item and len(item) > 2 and np.prod([a not in item for a in exclude_lst]) > 0:
            df_in_out_tables.append({'id':row['id'],'main':row['main'],
                                    'number_of_lines':row['number_of_lines'],
                                    'path':row['path'],'fname':row['fname'],
                                    'folder':row['folder'],'criticality':row['criticality'],
                                    'global_usecase':row['global_usecase'],
                                    'number_of_active_users':row['number_of_active_users'],
                                    'number_of_inactive_users':row['number_of_inactive_users'],
                                    'LoB':row['LoB'] + ' (in)', 'usecase_name':str(row['usecase_name']) + ' (in)',
                                    'table':item,'in': 1, 'out': 0})
            
    for item in out_tbls:
        if item != '' and '%' not in item and len(item) > 2 and np.prod([a not in item for a in exclude_lst]) > 0:
            df_in_out_tables.append({'id':row['id'],'main':row['main'],
                                    'number_of_lines':row['number_of_lines'],
                                    'path':row['path'],'fname':row['fname'],
                                    'folder':row['folder'],'criticality':row['criticality'],
                                    'global_usecase':row['global_usecase'],
                                    'number_of_active_users':row['number_of_active_users'],
                                    'number_of_inactive_users':row['number_of_inactive_users'],
                                    'LoB':row['LoB'] + ' (out)', 'usecase_name':str(row['usecase_name']) + ' (out)',
                                    'table':item,'in': 0, 'out': 1})

df_in_out_tables = pd.DataFrame(df_in_out_tables)

df_in_out_tables_grp  = df_in_out_tables.groupby(['table'], as_index=False).agg({'LoB': lambda x: '|'.join(list(set([a.split('(in)')[0] for a in x if a.endswith('(in)')]))) +\
                                                                                 'in_out_separation:' + '|'.join(list(set([a.split('(out)')[0] for a in x if a.endswith('(out)')]))), 
                                                                                 'usecase_name': lambda x: '|'.join(list(set([a.split('(in)')[0] for a in x if a.endswith('(in)')]))) +\
                                                                                 'in_out_separation:' + '|'.join(list(set([a.split('(out)')[0] for a in x if a.endswith('(out)')]))), 
                                                                                 'in': 'sum',
                                                                                 'out': 'sum'}).reset_index(drop=True)

df_in_out_tables_grp[['consumer_LOBs','creator_LOBs']]                = df_in_out_tables_grp['LoB'].str.split('in_out_separation:',expand=True)
df_in_out_tables_grp[['consumer_usecases','creator_usecases']] = df_in_out_tables_grp['usecase_name'].str.split('in_out_separation:',expand=True)

df_in_out_tables_grp['consumer_LOBs'] = df_in_out_tables_grp['consumer_LOBs'].str.slice(0,32000)
df_in_out_tables_grp['creator_LOBs']  = df_in_out_tables_grp['creator_LOBs'].str.slice(0,32000)

df_in_out_tables_grp['consumer_usecases'] = df_in_out_tables_grp['consumer_usecases'].str.slice(0,32000)
df_in_out_tables_grp['creator_usecases']  = df_in_out_tables_grp['creator_usecases'].str.slice(0,32000)

df_in_out_tables_grp = df_in_out_tables_grp.rename(columns={'in': '# times consumed', 'out': '# times created'})

df_in_out_tables_grp = df_in_out_tables_grp.drop('LoB',axis=1)
df_in_out_tables_grp = df_in_out_tables_grp.drop('usecase_name',axis=1)


df_in_out_tables_grp.to_csv(os.path.join(path_to_save,'df_in_out_tables_grp.csv'), encoding='latin-1')

# Adding the library definition to the input output tables

df_sas_programs_details = pd.read_csv(os.path.join(path,'df_sas_programs_details.csv'), sep=',')
df_sas_programs_details = df_sas_programs_details[(df_sas_programs_details['type'] == 'libname')]
df_sas_programs_details['library'] = df_sas_programs_details['original'].str.lower().str.strip().str.split(' ',expand=True)[1]

df_in_out_tables['library'] = df_in_out_tables['table'].str.lower().str.strip().str.split('.',expand=True)[0]
df_in_out_tables = pd.merge(df_in_out_tables, df_sas_programs_details[['id','library','type','original','key','value_0']], on=['id','library'], how='left')
df_in_out_tables.loc[df_in_out_tables['library'] == '', 'library'] = 'work'
df_in_out_tables['value_0'] = df_in_out_tables['value_0'].str.replace('[','').str.replace(']','').str.replace('"','').str.replace("'","").str.strip().str.lower()
df_in_out_tables = df_in_out_tables.rename(columns={'key': 'engine'})

df_in_out_tables['LoB'] = [a.split("(in)")[0] for a in df_in_out_tables['LoB'].values]
df_in_out_tables['LoB'] = [a.split("(out)")[0] for a in df_in_out_tables['LoB'].values]
df_in_out_tables['usecase_name'] = [a.split("(in)")[0] for a in df_in_out_tables['usecase_name'].values] 
df_in_out_tables['usecase_name'] = [a.split("(out)")[0] for a in df_in_out_tables['usecase_name'].values] 
df_in_out_tables.to_csv(os.path.join(path_to_save,'df_in_out_tables.csv'), encoding='latin-1')


###############################################################
# Compute interdependencies
###############################################################
df_dep = pd.read_csv(os.path.join(path,'df_dep.csv'), sep=',')
df_dep = pd.merge(df_dep, df_sas_programs_main_matrix[['id','usecase_name','LoB','criticality','global_usecase']], on='id', how='inner')
df_dep_nodup = df_dep.drop_duplicates(subset=['folder','reference', 'url'])
pivot_table = pd.pivot_table(df_dep_nodup, values='url', index='folder', columns='reference', aggfunc='count')
pivot_table = pivot_table.fillna(0)
pivot_table['Sum'] = pivot_table.sum(axis=1)
pivot_table = pivot_table.sort_values(by='Sum', ascending=False)
pivot_table = pivot_table.transpose()
pivot_table['Sum'] = pivot_table.sum(axis=1)
pivot_table = pivot_table.sort_values(by='Sum', ascending=False)
pivot_table = pivot_table.transpose()
pivot_table.replace(0, '', inplace=True)
df_dep_nodup.to_csv(os.path.join(path_to_save,'df_dependencies.csv'))
pivot_table.to_csv(os.path.join(path_to_save,'df_dependencies_pivot.csv'))


###############################################################
# Compute most referenced places
###############################################################

df_reference = df_dep[['folder','reference','type','url']].\
    groupby(['reference','url'], as_index=False).\
        agg({'folder': 'count'}).\
            reset_index(drop=True).\
                sort_values(by='folder', ascending=False)
df_reference = df_reference.rename(columns={'folder': 'Count'})
df_reference.to_csv(os.path.join(path_to_save,'df_reference.csv'))

df_include = df_dep[df_dep['type']=='include'].groupby(['reference','url'], as_index=False).\
        agg({'folder': 'count'}).\
            reset_index(drop=True).\
                sort_values(by='folder', ascending=False)
df_include = df_include.rename(columns={'folder': 'Count'})
df_include.to_csv(os.path.join(path_to_save,'df_include.csv'))

print(df_include)


###############################################################
# combine original SAS content assessment file with criticality
###############################################################

df_sas_programs_main_matrix['full_name'] = df_sas_programs_main['path'] + '/' + df_sas_programs_main['fname']
df_original_SAS_content_assessment = pd.read_csv(os.path.join(path_to_save,'original_SAS_content_assessment.csv'), sep=',',encoding='latin-1')
df_original_SAS_content_assessment_processed = pd.merge(df_original_SAS_content_assessment, df_sas_programs_main_matrix[['full_name','criticality','LoB','folder']], 
                                                        left_on='Scanned Program Name',right_on='full_name',how='left')
df_original_SAS_content_assessment_processed.to_csv(os.path.join(path_to_save,'df_original_SAS_content_assessment_processed.csv'),encoding='latin-1')


###############################################################
# Compute program similarities
###############################################################
df_sas_programs_sim = pd.read_csv(os.path.join(path,'df_sas_programs_sim.csv'), sep=',')

df_sas_programs_sim = pd.merge(df_sas_programs_sim, df_sas_programs_main_matrix[['id','LoB','folder','global_usecase','usecase_name','criticality']], 
                               left_on='id1', right_on='id', how='inner')
df_sas_programs_sim = df_sas_programs_sim.rename(columns={'LoB':'LoB1','folder':'folder1','global_usecase':'global_usecase1',
                                                          'usecase_name':'usecase_name1','criticality':'criticality1'})

df_sas_programs_sim = pd.merge(df_sas_programs_sim, df_sas_programs_main_matrix[['id','LoB','folder','global_usecase','usecase_name','criticality']], 
                               left_on='id2', right_on='id', how='inner')
df_sas_programs_sim = df_sas_programs_sim.rename(columns={'LoB':'LoB2','folder':'folder2','global_usecase':'global_usecase2',
                                                          'usecase_name':'usecase_name2','criticality':'criticality2'})

df_sas_programs_sim = df_sas_programs_sim[df_sas_programs_sim['id1'] != df_sas_programs_sim['id2']]
df_sas_programs_sim.to_csv(os.path.join(path_to_save,'df_sas_programs_avg_sim.csv'))
df_sas_programs_sim.groupby('global_usecase1', as_index=False).agg({'similarity': 'mean'}).reset_index(drop=True).to_csv(os.path.join(path_to_save,'df_sas_programs_avg_sim.csv'))
df_sas_programs_sim[df_sas_programs_sim['similarity'] >= 0.5].to_csv(os.path.join(path_to_save,'df_sas_programs_sim_bigger_than_05.csv'))
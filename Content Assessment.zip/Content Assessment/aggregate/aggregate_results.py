import os
import pandas as pd
import re

path = "C:\SAEED\EY-TN-Accelerators\EY-CA-TN\Content Assessment\outputs_Rogers"

##################################################################################
##################################################################################
##################################################################################
##################################################################################
##################################################################################
# Function definition
##################################################################################
##################################################################################
##################################################################################
##################################################################################
##################################################################################

def find_pattern(text):

    # Pattern 1: "/a" followed by two digits and a "/"
    pattern1 = re.compile(r'/a\d{2}/')

    # Pattern 2: "/sasprd"
    pattern2 = re.compile(r'/sasprd/')

    # Pattern 3: "/certif"
    pattern3 = re.compile(r'/certif/')

    # Find matches for both patterns
    matches_pattern1 = re.findall(pattern1, text)
    matches_pattern2 = re.findall(pattern2, text)
    matches_pattern3 = re.findall(pattern3, text)

    matches_pattern1 = [a.replace('/','') for a in matches_pattern1]
    matches_pattern2 = [a.replace('/','') for a in matches_pattern2]
    matches_pattern3 = [a.replace('/','') for a in matches_pattern3]

    if matches_pattern1 != []:
        return matches_pattern1
    elif matches_pattern2 != []:
        return matches_pattern2
    elif matches_pattern3 != []:
        return matches_pattern3
    else:
        return []
        
def find_stored_procs(text):

    pattern = r'%stpbegin(.*?)%stpend'

    # Find matches for both patterns
    matches_pattern = re.findall(pattern, text.lower())

    matches_pattern = [a for a in matches_pattern]

    return matches_pattern

def find_username(text):

    pattern1 = r'username'
    pattern2 = r'password'
    pattern3 = r'fcc'
    pattern4 = r'first.*?name'
    pattern5 = r'last.*?name'
    pattern6 = r'phone.*?number'

    # Find matches for both patterns
    matches_pattern1 = re.findall(pattern1, text.lower())
    matches_pattern2 = re.findall(pattern2, text.lower())
    matches_pattern3 = re.findall(pattern3, text.lower())
    matches_pattern4 = re.findall(pattern4, text.lower())
    matches_pattern5 = re.findall(pattern5, text.lower())
    matches_pattern6 = re.findall(pattern6, text.lower())

    matches_pattern1.extend(matches_pattern2)
    matches_pattern1.extend(matches_pattern3)
    matches_pattern1.extend(matches_pattern4)
    matches_pattern1.extend(matches_pattern5)
    matches_pattern1.extend(matches_pattern6)

    return matches_pattern1

def find_stored_condition(text):

    pattern1 = r'if(.*?)end'
    pattern2 = r'when(.*?)end'
    pattern3 = r'if(.*?)then'

    # Find matches for both patterns
    matches_pattern1 = re.findall(pattern1, text.lower())
    matches_pattern2 = re.findall(pattern2, text.lower())
    matches_pattern3 = re.findall(pattern3, text.lower())

    matches_pattern1 = [a for a in matches_pattern1]
    matches_pattern2 = [a for a in matches_pattern2]
    matches_pattern3 = [a for a in matches_pattern3]

    matches_pattern1.extend(matches_pattern2)
    matches_pattern1.extend(matches_pattern3)

    return matches_pattern1

def find_loop(text):

    pattern1 = r'do(.*?)to(.*?)end'
    pattern2 = r'do(.*?)while(.*?)end'
    pattern3 = r'do(.*?)until(.*?)end'

    # Find matches for both patterns
    matches_pattern1 = re.findall(pattern1, text.lower())
    matches_pattern2 = re.findall(pattern2, text.lower())
    matches_pattern3 = re.findall(pattern3, text.lower())

    matches_pattern1 = [a for a in matches_pattern1]
    matches_pattern2 = [a for a in matches_pattern2]
    matches_pattern3 = [a for a in matches_pattern3]

    matches_pattern1.extend(matches_pattern2)
    matches_pattern1.extend(matches_pattern3)

    return matches_pattern1

def find_x_command(text):

    pattern1 = r' x (.*?);'
    pattern2 = r'\nx (.*?);'

    # Find matches for both patterns
    matches_pattern1 = re.findall(pattern1, text.lower())
    matches_pattern2 = re.findall(pattern2, text.lower())

    matches_pattern1 = [a for a in matches_pattern1]
    matches_pattern2 = [a for a in matches_pattern2]

    matches_pattern1.extend(matches_pattern2)

    return matches_pattern1

def find_pass_through(text):

    pattern1 = r'connect to(.*?)as'

    # Find matches for both patterns
    matches_pattern1 = re.findall(pattern1, text.lower())

    matches_pattern1 = [a for a in matches_pattern1]

    return matches_pattern1

def find_hash(text):

    pattern1 = r'declare hash(.*?)'

    # Find matches for both patterns
    matches_pattern1 = re.findall(pattern1, text.lower())

    matches_pattern1 = [a for a in matches_pattern1]

    return matches_pattern1

def find_index(text):

    pattern1 = r'index create(.*?)'

    # Find matches for both patterns
    matches_pattern1 = re.findall(pattern1, text.lower())

    matches_pattern1 = [a for a in matches_pattern1]

    return matches_pattern1


##################################################################################
##################################################################################
##################################################################################
##################################################################################
##################################################################################

def aggregate():
    
    subs = [os.path.join(path,a) for a in os.listdir(path) if a.startswith('outputs_')]

    def find_file(folder,file_name,multiple=False):
        f_name = [a[2] for a in os.walk(folder)][0]
        f_name = [a for a in f_name if a.startswith(file_name)]
        if f_name != []:
            return f_name[0] if multiple == False else f_name
        else:
            return None
    

    # ###############################################################
    # # Reading sas table relationships
    # ###############################################################

    df_sas_programs_table_relationships = pd.DataFrame()
    for item in subs:
        f_name = find_file(item, 'sas_programs_table_relationships')
        if f_name == None:
            continue
        try:
            df = pd.read_csv(os.path.join(item,f_name))
            df['id']  = item.split('_')[-1] + '_' + df['id'].astype(str)
            df_sas_programs_table_relationships = pd.concat([df_sas_programs_table_relationships, df], ignore_index=True, sort=False)
            print(f_name)
        except:
            print("Warning! " + f_name + " was not successfully loaded")

    df_sas_programs_table_relationships.to_csv(os.path.join(path,'df_sas_programs_table_relationships.csv'), sep=',')
    print('Reading sas table relationships successfully finished')

    ###############################################################
    # Reading the sas program names and number of lines
    ###############################################################

    df_path_to_folder = pd.read_csv(os.path.join(os.getcwd(),'map_path_to_folder.csv'), sep=',', encoding='latin-1')

    # df_sas_programs_main = pd.read_csv(os.path.join(path,'df_sas_programs_main.csv'), sep=',', encoding='latin-1')

    df_sas_programs_main = pd.DataFrame()
    for item in subs:
        f_name = find_file(item, 'sas_programs_main')
        try:
            df = pd.read_csv(os.path.join(item,f_name))
            df['id']  = item.split('_')[-1] + '_' + df['id'].astype(str)
            df['folder'] = ''
            df['stp'] = ''
            df['count_stp'] = 0
            df['count_cond'] = 0
            df['count_loop'] = 0
            df['pass_through'] = 0
            df['hash'] = 0
            df['index_create'] = 0
            df['username'] = 0
            df['x_command'] = ''
            df['count_x_command'] = 0
            for indx, row in df.iterrows():
                folder = [a[1] for a in df_path_to_folder[['path','folder']].values if a[0] in row['path']]
                if len(folder) == 0:
                    print('Equivalent folder not found for {0}!'.format(row['path']))
                temp_stp = find_stored_procs(row['program_code'])
                temp_cond = find_stored_condition(row['program_code'])
                temp_loop = find_loop(row['program_code'])
                temp_pass_throught = find_pass_through(row['program_code'])
                temp_hash = find_hash(row['program_code'])
                temp_index_create = find_index(row['program_code'])
                temp_username = find_username(row['program_code'])
                temp_x_command = find_x_command(row['program_code'])
                df.loc[indx,'folder'] = folder[0] if len(folder) > 0 else ''
                df.loc[indx,'stp'] = ','.join(temp_stp)
                df.loc[indx,'count_stp'] = len(re.findall('stpbegin',row['program_code'].lower()))
                df.loc[indx,'count_cond'] = len(temp_cond)
                df.loc[indx,'count_loop'] = len(temp_loop)
                df.loc[indx,'pass_through'] = len(temp_pass_throught)
                df.loc[indx,'hash'] = len(temp_hash)
                df.loc[indx,'index_create'] = len(temp_index_create)
                df.loc[indx,'username'] = len(temp_username)
                df.loc[indx,'x_command'] = ' | '.join(temp_x_command)
                df.loc[indx,'count_x_command'] = len(temp_x_command)
            df_sas_programs_main = pd.concat([df_sas_programs_main, df.loc[:,df.columns != 'program_code']], ignore_index=True, sort=False)
            print(f_name)
        except Exception as e:
            print(e)
            print("Warning! " + f_name + " was not successfully loaded")


    print('Number of detected SAS programs are: {0}'.format(str(df.shape[0])))
    df_sas_programs_main.to_csv(os.path.join(path,'df_sas_programs_main.csv'), sep=',')
    print('Reading the sas program names and number of lines successfully finished')

    ###############################################################
    # Reading proc statements
    ###############################################################

    df_sas_programs_proc_list = pd.DataFrame()
    for item in subs:
        f_name = find_file(item, 'sas_programs_proc_list')
        try:
            df = pd.read_csv(os.path.join(item,f_name))[['id','proc']]
            df['id']  = item.split('_')[-1] + '_' + df['id'].astype(str)
            df_sas_programs_proc_list = pd.concat([df_sas_programs_proc_list, df], ignore_index=True, sort=False)
            print(f_name)
        except:
            print("Warning! " + f_name + " was not successfully loaded")

    df_sas_programs_proc_list.to_csv(os.path.join(path,'df_sas_programs_proc_list.csv'), sep=',')
    print('Reading hard coded paths successfully finished')

    ###############################################################
    # Reading hard coded paths
    ###############################################################

    df_sas_programs_hard_coded_paths = pd.DataFrame()
    for item in subs:
        f_name = find_file(item, 'sas_programs_hard_coded_paths')
        try:
            df = pd.read_csv(os.path.join(item,f_name))[['id','hrd_code']]
            df['id']  = item.split('_')[-1] + '_' + df['id'].astype(str)
            df_sas_programs_hard_coded_paths = pd.concat([df_sas_programs_hard_coded_paths, df], ignore_index=True, sort=False)
            print(f_name)
        except:
            print("Warning! " + f_name + " was not successfully loaded")

    df_sas_programs_hard_coded_paths.to_csv(os.path.join(path,'df_sas_programs_hard_coded_paths.csv'), sep=',')
    print('Reading hard coded paths successfully finished')

    ###############################################################
    # Reading program statements
    ###############################################################

    df_sas_programs_details = pd.DataFrame()
    for item in subs:
        f_name = find_file(item, 'sas_programs_details')
        try:
            df = pd.read_csv(os.path.join(item,f_name))
            df['id']  = item.split('_')[-1] + '_' + df['id'].astype(str)
            df_sas_programs_details = pd.concat([df_sas_programs_details, df], ignore_index=True, sort=False)
            print(f_name)
        except:
            print("Warning! " + f_name + " was not successfully loaded")
            
    df_sas_programs_details.to_csv(os.path.join(path,'df_sas_programs_details.csv'), sep=',')

    ###############################################################
    # Reading program interdependencies
    ###############################################################

    df_sas_programs_details = pd.merge(df_sas_programs_details, df_sas_programs_main[['id','folder']], on='id', how='inner')

    df_dep = []
    for indx, row in df_sas_programs_details.iterrows():
        res = [a for a in df_path_to_folder['folder'].values if a in row['value_0']]
        if len(res) > 0:
            val = row['value_0'].replace('"','').replace("'","").replace("[","").replace("]","").replace("\t","")
            val = val[0:-1] if val.endswith('/') else val
            df_dep.append([row['id'], row['folder'], res[0], row['type'], val])

        if indx % 100000 == 0:
            print('program dependencies {0}'.format(str(indx)))

    df_dep = pd.DataFrame(df_dep, columns=['id','folder', 'reference','type','url'])

    df_dep.to_csv(os.path.join(path,'df_dep.csv'), sep=',')
    print('Reading program statements successfully finished')


    ###############################################################
    # Reading program similarities
    ###############################################################

    df_sas_programs_sim = pd.DataFrame()
    for item in subs:
        f_names = find_file(item, 'sas_programs_sim', multiple=True)    
        if f_names != None:
            try:
                df = pd.DataFrame()
                for ff in f_names:
                    df_temp = pd.read_csv(os.path.join(item,ff))
                    # df_temp = df_temp[(df_temp['similarity'] >= 0.5) & (df_temp['similarity'] <= 1)]
                    df = pd.concat([df, df_temp], ignore_index=True, sort=False)
                df['id1']  = item.split('_')[-1] + '_' + df['id1'].astype(str)
                df['id2']  = item.split('_')[-1] + '_' + df['id2'].astype(str)
                df_sas_programs_sim = pd.concat([df_sas_programs_sim, df], ignore_index=True, sort=False)
                print(item)
            except:
                print("Warning! " + f_names[0] + " was not successfully loaded")


    df_sas_programs_sim.to_csv(os.path.join(path,'df_sas_programs_sim.csv'), sep=',')
    print('Reading program similarities successfully finished')




def add_filter():

    path = "C:\BNC Content Assessment\sasdev_Analysis\original"

    df_sas_programs_main             = pd.read_csv(os.path.join(path,'df_sas_programs_main.csv'), sep=',')
    df_sas_programs_proc_list        = pd.read_csv(os.path.join(path,'df_sas_programs_proc_list.csv'), sep=',')
    df_sas_programs_hard_coded_paths = pd.read_csv(os.path.join(path,'df_sas_programs_hard_coded_paths.csv'), sep=',')
    df_sas_programs_details          = pd.read_csv(os.path.join(path,'df_sas_programs_details.csv'), sep=',')
    df_dep                           = pd.read_csv(os.path.join(path,'df_dep.csv'), sep=',')
    df_sas_programs_sim              = pd.read_csv(os.path.join(path,'df_sas_programs_sim.csv'), sep=',')


    df_sas_programs_main             = df_sas_programs_main[df_sas_programs_main['main'] == 'prod']
    df_sas_programs_proc_list        = pd.merge(df_sas_programs_proc_list,        df_sas_programs_main['id'], on='id', how='inner')
    df_sas_programs_hard_coded_paths = pd.merge(df_sas_programs_hard_coded_paths, df_sas_programs_main['id'], on='id', how='inner')
    df_sas_programs_details          = pd.merge(df_sas_programs_details,          df_sas_programs_main['id'], on='id', how='inner')
    df_sas_programs_sim              = pd.merge(df_sas_programs_sim,              df_sas_programs_main['id'], left_on='id1', right_on='id', how='inner')

    path = "C:\BNC Content Assessment\sasdev_Analysis\prod"

    df_sas_programs_main.to_csv(os.path.join(path,'df_sas_programs_main.csv'), sep=',')
    df_sas_programs_proc_list.to_csv(os.path.join(path,'df_sas_programs_proc_list.csv'), sep=',')
    df_sas_programs_hard_coded_paths.to_csv(os.path.join(path,'df_sas_programs_hard_coded_paths.csv'), sep=',')
    df_sas_programs_details.to_csv(os.path.join(path,'df_sas_programs_details.csv'), sep=',')
    df_sas_programs_sim.to_csv(os.path.join(path,'df_sas_programs_sim.csv'), sep=',')


    df_dep = []
    for indx, row in df_sas_programs_details.iterrows():
        temp = row['id'].split('_')[0]
        res = find_pattern(row['original'])
        if len(res) > 0:
            df_dep.append([temp, res[0]])

        if indx % 100000 == 0:
            print('program dependencies {0}'.format(str(indx)))    

    df_dep = pd.DataFrame(df_dep, columns=['id','original'])
    df_dep.to_csv(os.path.join(path,'df_dep.csv'), sep=',')




aggregate()
# add_filter()
